import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import fcntl
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
from time import monotonic
from urllib.parse import unquote, urlsplit

from arxiv_zh_pdf import WorkflowError, fetch, is_pdf, parse_paper, preflight, prepare
from translation_batches import SCHEMA, save_text, translate_sources, translation_complete, translation_fingerprint


SKILL = Path(__file__).resolve().parent.parent
UI = SKILL / "web"
ASSETS = {"/": UI / "index.html", "/reader.css": UI / "reader.css", "/reader.mjs": UI / "reader.mjs",
          "/alignment.mjs": UI / "alignment.mjs", "/logo.svg": SKILL / "assets/logo.svg"}
PDFS = {"original.pdf", "translated.zh.pdf", "translated.zh-draft.pdf"}
JOB_KEY = re.compile(r"[a-zA-Z0-9.-]{1,80}")
PDF_JS = re.compile(r"(?:pdf(?:\.worker)?\.min\.mjs|(?:cmaps|standard_fonts|wasm|iccs)/[a-zA-Z0-9_.-]+)\Z")
CONTENT_POLICY = (
    "default-src 'self'; script-src 'self'; worker-src 'self' blob:; "
    "font-src 'self' blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
    "object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
)


def pdfjs_path(custom):
    bundled = (Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/pdfjs-dist")
    candidates = [Path(custom).expanduser()] if custom else [UI / "node_modules/pdfjs-dist", bundled]
    for path in candidates:
        if all((path / "build" / name).is_file() for name in ("pdf.min.mjs", "pdf.worker.min.mjs")):
            return path.resolve()
    raise WorkflowError("找不到 PDF.js。请安装 pdfjs-dist@5.6.205 或用 --pdfjs 指向 Codex 的依赖目录。")


def optional_metadata(job):
    path = job / "reader.json"
    if not path.is_file() or path.is_symlink() or path.stat().st_size > 32 * 1024:
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def regular_pdf(path):
    try:
        return not path.is_symlink() and is_pdf(path)
    except OSError:
        return False


@contextmanager
def paper_lock(job):
    descriptor = os.open(job / ".translation.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise WorkflowError("这个版本正在另一个阅读器或终端里翻译，请等它完成。") from None
        yield
    finally:
        os.close(descriptor)


class Shelf:
    def __init__(self, root, codex, model, max_thinking, workers):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.codex = codex
        self.model = model
        self.max_thinking = max_thinking
        self.workers = workers
        self.task = None
        self.lock = threading.Lock()
        self.executor = ThreadPoolExecutor(max_workers=1)
        self.processes = set()
        self.stopping = False

    def job_dir(self, key):
        if not JOB_KEY.fullmatch(key) or key.startswith("."):
            return None
        path = self.root / key
        if path.is_symlink() or not path.is_dir():
            return None
        return path

    def item(self, key):
        job = self.job_dir(key)
        if not job or not regular_pdf(job / "original.pdf"):
            return None
        metadata = optional_metadata(job)
        full = regular_pdf(job / "translated.zh.pdf")
        draft = not full and regular_pdf(job / "translated.zh-draft.pdf")
        zh = "translated.zh.pdf" if full else "translated.zh-draft.pdf" if draft else None
        return {"id": key, "paper": key.replace("--", "/"), "title": metadata.get("title", ""),
                "titleEn": metadata.get("titleEn", ""), "scope": metadata.get("draftScope", "") if draft else "",
                "original": f"/papers/{key}/original.pdf", "translated": f"/papers/{key}/{zh}" if zh else None,
                "draft": draft}

    def status(self):
        papers = [item for path in self.root.iterdir() if (item := self.item(path.name))]
        papers.sort(key=lambda item: (item["translated"] is None, item["id"]))
        with self.lock:
            task = self.task.copy() if self.task else None
        return {"papers": papers, "task": task, "engine": bool(self.codex)}

    def update(self, **changes):
        with self.lock:
            self.task.update(changes)

    def start(self, paper):
        key = paper.replace("/", "--")
        existing = self.item(key)
        if existing and existing["translated"] and not existing["draft"]:
            return {"open": key}
        if not self.codex:
            return {"open": key} if existing else {"manual": paper}
        with self.lock:
            if self.task and self.task["state"] in {"fetching", "translating", "checking"}:
                return {"busy": self.task.copy()}
            self.task = {"state": "fetching", "paper": paper, "id": None}
        self.executor.submit(self.run, paper)
        return {"started": True}

    def run(self, paper, main=None):
        try:
            stage = monotonic()
            result = fetch(paper, self.root)
            fetch_seconds = round(monotonic() - stage, 2)
            job = Path(result["job"])
            self.update(id=job.name, paper=result["arxiv"])
            with paper_lock(job):
                item = self.item(job.name)
                if not (item and item["translated"] and not item["draft"]):
                    self.finish(job, main, result["arxiv"], fetch_seconds)
                self.update(state="ready")
        except Exception as error:
            self.update(state="error", message=str(error)[:350])

    def finish(self, job, main, paper, fetch_seconds):
        project = prepare(job, main)
        dependencies = preflight(job)
        if dependencies["missing"]:
            names = "、".join(dependencies["missing"])
            raise WorkflowError(f"缺少 TeX 依赖：{names}。补齐后重新提交，无需重新下载。")
        stage = monotonic()
        if not translation_complete(job, project["main"]):
            self.update(state="translating")
            self.translate(job, project["main"])
            save_text(job / ".translation-complete", json.dumps(translation_fingerprint(job, project["main"])))
        translate_seconds = round(monotonic() - stage, 2)
        self.update(state="checking")
        result = self.build(job)
        output = self.item(job.name)
        if not output or not output["translated"] or output["draft"]:
            raise WorkflowError("没有生成通过检查的全文译稿，草稿不会被标成全文。")
        report = {"paper": paper, "fetch_seconds": fetch_seconds, "translate_seconds": translate_seconds,
                  "build": result}
        save_text(job / "run-report.json", json.dumps(report, ensure_ascii=False, indent=2))

    def translate(self, job, main):
        with tempfile.TemporaryDirectory(prefix=".reader-batch-", dir=job) as directory:
            work = Path(directory)
            schema = work / "schema.json"
            schema.write_text(json.dumps(SCHEMA), encoding="utf-8")

            def request(prompt, index, attempt):
                reply = work / f"batch-{index}-{attempt}.json"
                effort = self.max_thinking if attempt >= 2 else "low"
                model_options = ["--model", self.model] if self.model else []
                model_name = self.model or "Codex 默认模型"
                command = [self.codex, "--ask-for-approval", "never", "exec", "--sandbox", "read-only",
                           "--ignore-user-config", "--ignore-rules", "--skip-git-repo-check", "--ephemeral",
                           "--disable", "plugins", "--disable", "shell_snapshot", "--disable", "shell_tool",
                           "--disable", "multi_agent", "-c", 'web_search="disabled"', *model_options,
                           "-c", f'model_reasoning_effort="{effort}"',
                           "--color", "never", "--output-schema",
                           str(schema), "--output-last-message", str(reply), "-"]
                status, log = self.run_command(command, work, job, prompt, 360,
                                               f"翻译第 {index} 批 · 尝试 {attempt + 1} · {model_name}/{effort}")
                if status:
                    errors = "\n".join(line for line in log.splitlines() if line.startswith("ERROR:"))
                    if re.search(r"model_not_found|not supported when using Codex|model.{0,100}does not exist", errors, re.I):
                        raise WorkflowError(f"当前 Codex 账号未能使用 {model_name}。可用 --model 指定账号支持的模型后重试。")
                    if re.search(r"usage.limit|insufficient_quota|rate.limit", errors, re.I):
                        raise WorkflowError("Codex 达到用量或请求限制。有效译文已保留，稍后可重新提交。")
                    return {}
                try:
                    value = json.loads(reply.read_text(encoding="utf-8"))
                    return value if isinstance(value, dict) else {}
                except (OSError, ValueError):
                    return {}

            translate_sources(job, main, request, lambda done, total: self.update(completed=done, batches=total), self.workers)

    def build(self, job):
        script = SKILL / "scripts/arxiv_zh_pdf.py"
        command = [self.codex, "sandbox", "--permission-profile", ":workspace", "--cd", str(job), "--",
                   sys.executable, "-B", str(script), "build", str(job)]
        status, log = self.run_command(command, job, job, "", 900, "编译并验证中文 PDF")
        if status:
            lines = log.strip().splitlines()
            detail = next((line for line in lines if line.startswith("错误：")),
                          lines[-1] if lines else "编译进程没有返回诊断。")
            raise WorkflowError(f"{detail.removeprefix('错误：')}（详见 reader-codex.log）")
        start = log.find("{\n")
        end = log.rfind("\n}")
        try:
            return json.loads(log[start:end + 2]) if 0 <= start < end else {}
        except ValueError:
            return {}

    def run_command(self, command, cwd, job, prompt, timeout, stage):
        with tempfile.NamedTemporaryFile(prefix=".reader-run-", dir=job) as stream:
            with self.lock:
                if self.stopping:
                    raise WorkflowError("阅读器已停止。")
                process = subprocess.Popen(command, cwd=cwd, stdin=subprocess.PIPE, stdout=stream,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                self.processes.add(process)
            try:
                process.communicate(prompt.encode("utf-8"), timeout=timeout)
            except subprocess.TimeoutExpired:
                self.stop_process(process)
            finally:
                stream.seek(max(0, stream.seek(0, os.SEEK_END) - 32 * 1024))
                tail = stream.read().decode("utf-8", errors="replace")
                log = job / "reader-codex.log"
                with self.lock:
                    self.processes.discard(process)
                    if not log.is_symlink():
                        log.write_text(f"{stage}\n{tail}", encoding="utf-8")
        return process.returncode, tail

    @staticmethod
    def stop_process(process):
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=3)
            except ProcessLookupError:
                pass
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()

    def close(self):
        with self.lock:
            self.stopping = True
            processes = list(self.processes)
        for process in processes:
            self.stop_process(process)
        self.executor.shutdown(wait=False, cancel_futures=True)


def byte_range(value, size):
    if not value:
        return 0, size - 1, False
    match = re.fullmatch(r"bytes=(\d{0,18})-(\d{0,18})", value)
    if not match or not any(match.groups()):
        raise ValueError("invalid range")
    if match[1]:
        start = int(match[1])
        end = min(int(match[2]), size - 1) if match[2] else size - 1
    else:
        start, end = max(0, size - int(match[2])), size - 1
    if start > end or start >= size:
        raise ValueError("range outside file")
    return start, end, True


class ReaderHandler(BaseHTTPRequestHandler):
    server_version = "ArxivReader"

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", CONTENT_POLICY)
        super().end_headers()

    def send_json(self, status, value, head=False):
        content = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        if not head:
            self.wfile.write(content)

    def allowed_host(self):
        return self.headers.get("Host") in self.server.hosts

    def do_GET(self):
        try:
            self.read_route(False)
        except (BrokenPipeError, ConnectionResetError):
            return

    def do_HEAD(self):
        self.read_route(True)

    def read_route(self, head):
        if not self.allowed_host():
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        path = unquote(urlsplit(self.path).path)
        if path in ASSETS:
            self.send_file(ASSETS[path], head)
        elif path == "/api/library":
            self.send_json(200, {**self.server.shelf.status(), "token": self.server.token}, head)
        elif path.startswith("/pdfjs/") and PDF_JS.fullmatch(asset := path.removeprefix("/pdfjs/")):
            asset_path = self.server.pdfjs / (f"build/{asset}" if "/" not in asset else asset)
            self.send_file(asset_path, head)
        elif match := re.fullmatch(r"/papers/([^/]+)/([^/]+)", path):
            job = self.server.shelf.job_dir(match[1])
            if job and match[2] in PDFS and regular_pdf(job / match[2]):
                self.send_file(job / match[2], head, is_paper=True)
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def send_file(self, path, head, is_paper=False):
        if not path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        with path.open("rb") as stream:
            size = os.fstat(stream.fileno()).st_size
            try:
                start, end, partial = byte_range(self.headers.get("Range") if is_paper else None, size)
            except ValueError:
                self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                self.send_header("Content-Range", f"bytes */{size}")
                self.end_headers()
                return
            length = end - start + 1
            self.send_response(HTTPStatus.PARTIAL_CONTENT if partial else HTTPStatus.OK)
            content_type = "text/javascript" if path.suffix == ".mjs" else mimetypes.guess_type(path)[0]
            self.send_header("Content-Type", content_type or "application/octet-stream")
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-cache" if not is_paper else "no-store")
            if is_paper:
                self.send_header("Accept-Ranges", "bytes")
            if partial:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            if not head:
                stream.seek(start)
                while length and (chunk := stream.read(min(length, 128 * 1024))):
                    self.wfile.write(chunk)
                    length -= len(chunk)

    def do_POST(self):
        if self.path != "/api/translate":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        if (not self.allowed_host() or self.headers.get("Origin") != f"http://{self.headers.get('Host')}"
                or not secrets.compare_digest(self.headers.get("X-Reader-Token", ""), self.server.token)):
            self.send_json(403, {"error": "请求不是来自这个本地阅读器。"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 < size <= 4096 or self.headers.get_content_type() != "application/json":
                raise WorkflowError("请求格式不正确。")
            value = json.loads(self.rfile.read(size))
            if not isinstance(value, dict) or not isinstance(value.get("paper"), str):
                raise WorkflowError("请输入 arXiv 链接或编号。")
            paper = parse_paper(value["paper"])
            result = self.server.shelf.start(paper)
        except (ValueError, WorkflowError) as error:
            self.send_json(400, {"error": str(error)})
            return
        self.send_json(202 if result.get("started") else 200, result)


def main():
    parser = argparse.ArgumentParser(description="在本机打开 arXiv 中英对照阅读器。")
    parser.add_argument("--out", type=Path, default=Path("output/pdf/arxiv"), help="论文工作区根目录")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--pdfjs", help="本机 pdfjs-dist 根目录")
    parser.add_argument("--enable-codex", action="store_true", help="允许网页使用已登录的 Codex CLI 翻译")
    parser.add_argument("--model", help="翻译模型，不指定则使用 Codex CLI 默认模型")
    parser.add_argument("--max-thinking", choices=("low", "medium"), default="medium", help="失败片段重试时的推理上限")
    parser.add_argument("--workers", type=int, choices=range(1, 5), default=4, help="同一篇论文同时处理的批次数，默认 4")
    parser.add_argument("--translate", metavar="ARXIV", help="一次性翻译并生成中文 PDF，不启动网页")
    parser.add_argument("--main", metavar="TEX", help="与 --translate 一起指定归档中的主 .tex")
    args = parser.parse_args()
    if args.main and not args.translate:
        parser.error("--main 需与 --translate 一起使用")
    try:
        codex = shutil.which("codex") if args.enable_codex or args.translate else None
        if (args.enable_codex or args.translate) and not codex:
            raise WorkflowError("找不到 Codex CLI。请先安装并登录 Codex CLI；已有译文仍可用只读网页打开。")
        if args.translate:
            return one_shot(args, codex)
        pdfjs = pdfjs_path(args.pdfjs)
        with ThreadingHTTPServer(("127.0.0.1", args.port), ReaderHandler) as server:
            server.pdfjs = pdfjs
            server.token = secrets.token_urlsafe(24)
            port = server.server_port
            server.hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
            server.shelf = Shelf(args.out, codex, args.model, args.max_thinking, args.workers)
            print(f"＋云翻译 · http://127.0.0.1:{port}/", flush=True)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                server.shelf.close()
    except (OSError, WorkflowError) as error:
        parser.exit(1, f"错误：{error}\n")


def one_shot(args, codex):
    shelf = Shelf(args.out, codex, args.model, args.max_thinking, args.workers)
    try:
        paper = parse_paper(args.translate)
        key = paper.replace("/", "--")
        existing = shelf.item(key)
        if not (existing and existing["translated"] and not existing["draft"]):
            shelf.task = {"state": "fetching", "paper": paper, "id": None}
            shelf.run(paper, args.main)
            if shelf.task["state"] == "error":
                raise WorkflowError(shelf.task["message"])
            key = shelf.task["id"]
        path = shelf.job_dir(key)
        value = {"arxiv": key.replace("--", "/"), "pdf": str(path / "translated.zh.pdf")}
        receipt = path / "run-report.json"
        if not receipt.is_symlink() and receipt.is_file() and receipt.stat().st_size <= 64 * 1024:
            try:
                report = json.loads(receipt.read_text(encoding="utf-8"))
                checks = report.get("build")
                if isinstance(checks, dict):
                    value.update({name: checks[name] for name in ("overfull_boxes", "unresolved_refs") if checks.get(name)})
            except (AttributeError, OSError, ValueError):
                pass
        print(json.dumps(value, ensure_ascii=False))
    finally:
        shelf.close()


if __name__ == "__main__":
    main()
