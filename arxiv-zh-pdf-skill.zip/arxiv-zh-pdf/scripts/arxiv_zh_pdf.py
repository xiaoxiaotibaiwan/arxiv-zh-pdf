import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import filecmp
import gzip
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from time import perf_counter
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


ARXIV = "https://arxiv.org"
ARXIV_HOSTS = {"arxiv.org", "export.arxiv.org", "www.arxiv.org"}
PAPER_ID = re.compile(
    r"(?:[0-9]{2}(?:0[1-9]|1[0-2])\.[0-9]{4,5}|[a-z][a-z0-9.-]*/[0-9]{7})"
    r"(?:v[1-9][0-9]*)?", re.IGNORECASE | re.ASCII
)
LIMIT_BYTES = 250 * 1024 * 1024
DOCUMENT = re.compile(r"\\begin\s*\{document\}")
CLASS = re.compile(r"\\documentclass\b")
COMMENT = re.compile(r"(?m)(?<!\\)((?:\\\\)*)%[^\r\n]*")
HAN = re.compile(r"[\u3400-\u9fff]")
LAYOUT_ARGUMENTS = re.compile(
    r"\\begin\s*\{(?:adjustbox|tabular\*?|tabularx|tabulary|array|longtable|minipage|multicols)\}"
    r"\s*(?:\[[^\]\n]*\]\s*)?\{(?:[^{}\n]|\{[^{}\n]*\})*\}"
    r"|\\begin\s*\{(?:figure\*?|table\*?|wrapfigure|wraptable|tcolorbox|lstlisting|enumerate|itemize|"
    r"subfigure|subtable|minipage)\}[ \t]*\[[^\]\n]*\]"
    r"|\\(?:multirow|multicolumn|resizebox|rotatebox|scalebox)\*?(?:\[[^\]\n]*\])?"
    r"\s*\{(?:[^{}\n]|\{[^{}\n]*\})*\}"
)
PROTECTED = {
    "公式": re.compile(
        r"(?s)(?<!\\)\$\$.*?(?<!\\)\$\$|(?<![\\$])\$(?!\$).*?(?<!\\)\$(?!\$)"
        r"|(?<!\\)\\\(.*?(?<!\\)\\\)|(?<!\\)\\\[.*?(?<!\\)\\\]"
        r"|\\begin\{(?P<env>(?:equation|align|alignat|flalign|gather|multline|eqnarray|displaymath|math)\*?)\}"
        r".*?\\end\{(?P=env)\}"
    ),
    "引用、模板和资源": re.compile(
        r"\\(?:[a-z]*cite[a-z]*|(?:[a-z]*ref)|label|bibitem|bibliography(?:style)?|addbibresource|"
        r"documentclass|input|include|subfile|includegraphics|includepdf|url|href)\*?"
        r"(?:\s*\[[^\]]*\])*\s*\{[^{}]*\}", re.IGNORECASE | re.ASCII,
    ),
    "环境": re.compile(r"\\(?:begin|end)\s*\{[^{}]+\}"),
    "表格和布局参数": LAYOUT_ARGUMENTS,
}
INCLUDED_TEX = re.compile(r"\\(?:input|include|subfile)\s*\{([^{}]+)\}")
PACKAGE = re.compile(r"\\(?:usepackage|RequirePackage)\s*(?:\[[^\]]*\]\s*)?\{([^{}]+)\}")
FONT_METRIC = re.compile(r"(?m)^\s*\\font\\[A-Za-z@]+\s*=\s*([A-Za-z0-9-]+)\s+(?:at|scaled)\b")
UNRESOLVED = re.compile(r"(?:Citation|Reference)(?:(?!\n\s*\n).){0,200}\bundefined\b|undefined references",
                        re.I | re.S)
TEX_ERROR = re.compile(r"^(?:[^\n]+?\.(?:tex|sty|cls):\d+:\s+(?:LaTeX Error|Package .+ Error|Undefined|"
                       r"Extra|Missing|File ended|Incomplete|Font .+ not loadable)|! (?!Emergency stop)|"
                       r"xdvipdfmx:fatal:)", re.I)
BIB_DATA = b"\\bibdata{"
BIB_LIST = re.compile(rb"\\@input\{([^{}\r\n]+\.aux)\}")
RERUN = re.compile(r"Label\(s\) may have changed|rerunfilecheck Warning: File|Rerun to get", re.I)
HEADING = re.compile(r"\\(icmltitle|title|chapter|(?:sub){0,2}section|(?:sub)?paragraph|caption)"
                     r"\*?\s*(?:\[[^\]]*\]\s*)?\{")
CODE_BLOCK = re.compile(r"(?s)\\begin\{(verbatim\*?|lstlisting|minted|tikzpicture|algorithmic|tabularx?\*?)\}"
                        r".*?\\end\{\1\}")
ENGLISH_WORD = re.compile(r"[A-Za-z]+(?:[-'][A-Za-z]+)*")
CJK = r"""\usepackage{xeCJK}
\setCJKmainfont[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolKai-Regular.otf]{FandolSong-Regular.otf}
\setCJKsansfont[BoldFont=FandolHei-Bold.otf]{FandolHei-Regular.otf}
\setCJKmonofont{FandolFang-Regular.otf}
"""


class WorkflowError(Exception):
    pass


def parse_paper(value):
    value = value.strip()
    if len(value) > 1024:
        raise WorkflowError("arXiv 链接或编号过长。")
    if re.match(r"https?://", value, re.IGNORECASE):
        url = urlsplit(value)
        path = unquote(url.path).strip("/")
        if url.netloc.lower() in ARXIV_HOSTS:
            match = re.fullmatch(r"(?:abs|pdf|html|src|e-print)/(.+)", path)
        elif url.netloc.lower() == "hjfy.top":
            match = re.fullmatch(r"arxiv/(.+)", path)
        elif url.netloc.lower() in {"doi.org", "dx.doi.org"}:
            match = re.fullmatch(r"10\.48550/arxiv\.(.+)", path, re.IGNORECASE)
        else:
            match = None
        value = match[1] if match else ""
    else:
        value = re.sub(r"^(?:arxiv:\s*|10\.48550/arxiv\.)", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\.pdf$", "", value, flags=re.IGNORECASE)
    if not PAPER_ID.fullmatch(value) or len(value) > 80:
        raise WorkflowError("请输入 arXiv 编号、arxiv.org 链接或幻觉翻译的 /arxiv/ 论文页。")
    return re.sub(r"V(?=[0-9]+$)", "v", value)


def explicit_version(paper):
    return re.search(r"v[1-9][0-9]*$", paper) is not None


class ArxivRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        url = urlsplit(newurl)
        if url.scheme != "https" or url.netloc.lower() not in ARXIV_HOSTS:
            raise WorkflowError("arXiv 返回了非预期的下载域名，已停止。")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def open_arxiv(path):
    request = Request(f"{ARXIV}/{path}", headers={"User-Agent": "Codex-arxiv-zh-pdf/1.0"})
    return build_opener(ArxivRedirect()).open(request, timeout=45)


def latest_version(paper, page):
    versions = re.findall(
        rf'''href\s*=\s*["'](?:https://(?:www\.)?arxiv\.org)?/abs/{re.escape(paper)}v([1-9][0-9]*)["']''',
        page, flags=re.IGNORECASE | re.ASCII,
    )
    if versions:
        return f"{paper}v{max(map(int, versions))}"
    raise WorkflowError(f"无法确认 {paper} 的具体版本。请用带 vN 的 arXiv 链接重试。")


def copy_limited(source, destination, limit=LIMIT_BYTES):
    size = 0
    while chunk := source.read(1024 * 1024):
        size += len(chunk)
        if size > limit:
            raise WorkflowError("文件超过工作流的大小上限。")
        destination.write(chunk)


def signature(path, length):
    with path.open("rb") as stream:
        return stream.read(length)


def is_pdf(path):
    return path.is_file() and signature(path, 5) == b"%PDF-"


def download(path, target, pdf=False):
    if target.is_symlink():
        raise WorkflowError(f"不复用符号链接：{target}。请换一个 --out 目录。")
    if target.exists():
        if not target.is_file() or (pdf and not is_pdf(target)):
            raise WorkflowError(f"现有文件无法复用：{target}。请换一个 --out 目录。")
        return
    with tempfile.TemporaryDirectory(prefix=".download-", dir=target.parent) as temp:
        partial = Path(temp) / "body"
        with open_arxiv(path) as response, partial.open("wb") as stream:
            if response.headers.get_content_type() == "text/html":
                raise WorkflowError(f"arXiv 没有提供可下载的文件：{path}。")
            copy_limited(response, stream)
        if not partial.stat().st_size or (pdf and not is_pdf(partial)):
            raise WorkflowError(f"arXiv 返回了空文件或非 PDF 内容：{path}。")
        partial.replace(target)


def fetch(value, output):
    paper = parse_paper(value)
    if not explicit_version(paper):
        with open_arxiv(f"abs/{paper}") as response:
            page = response.read(2 * 1024 * 1024).decode("utf-8", errors="replace")
        paper = latest_version(paper, page)
    job = output.resolve() / paper.replace("/", "--")
    if job.is_symlink():
        raise WorkflowError(f"不复用符号链接：{job}。请换一个 --out 目录。")
    job.mkdir(parents=True, exist_ok=True)
    original = job / "original.pdf"
    source = job / "source"
    if original.exists() and source.exists():
        download(f"pdf/{paper}", original, pdf=True)
        download(f"src/{paper}", source)
    else:
        with ThreadPoolExecutor(max_workers=2) as pool:
            src = pool.submit(download, f"src/{paper}", source)
            download(f"pdf/{paper}", original, pdf=True)
            try:
                src.result()
            except HTTPError as error:
                raise WorkflowError(f"arXiv 源码下载失败（HTTP {error.code}）。原文保存在 {original}") from error
    return {"arxiv": paper, "job": str(job), "original": str(original)}


def relative_path(value):
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or "\\" in value or "\0" in value:
        raise WorkflowError(f"不安全的源码路径：{value!r}。")
    return path


def unpack(archive_path, destination):
    with tempfile.TemporaryFile() as payload:
        open_source = gzip.open if signature(archive_path, 2) == b"\x1f\x8b" else open
        with open_source(archive_path, "rb") as source:
            copy_limited(source, payload)
        payload.seek(0)
        try:
            archive = tarfile.open(fileobj=payload, mode="r:")
        except tarfile.ReadError:
            payload.seek(0)
            raw = payload.read()
            text = raw.decode("utf-8-sig", errors="replace")
            if not (CLASS.search(without_comments(text)) and DOCUMENT.search(without_comments(text))):
                raise WorkflowError("arXiv 未提供可处理的 LaTeX 工程；已保留原始 PDF。") from None
            (destination / "main.tex").write_bytes(raw)
            return
        with archive:
            seen = set()
            for index, member in enumerate(archive):
                if index >= 4000:
                    raise WorkflowError("源码包条目过多。")
                path = relative_path(member.name)
                if not (member.isdir() or member.isreg()):
                    raise WorkflowError(f"源码包包含链接或特殊文件：{member.name!r}。")
                if not path.parts and member.isdir():
                    continue
                if not path.parts or any(part.lower() in {"agents.md", "agents.override.md", "texmf.cnf"}
                                         or part.startswith(".") for part in path.parts):
                    continue
                key = str(path).casefold()
                if key in seen:
                    raise WorkflowError(f"源码包含重复文件路径：{member.name!r}。")
                seen.add(key)
                target = destination.joinpath(*path.parts)
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as source, target.open("xb") as stream:
                        copy_limited(source, stream)


def without_comments(text):
    return COMMENT.sub(lambda match: match[1] + " " * (len(match[0]) - len(match[1])), text)


def tex_text(path):
    return path.read_text(encoding="utf-8-sig")


def choose_main(source, selected):
    if selected:
        main = source.joinpath(*relative_path(selected).parts)
        if main.suffix.lower() != ".tex" or not main.is_file():
            raise WorkflowError(f"找不到指定的主 .tex 文件：{selected}。")
        return main
    entries = set()
    for manifest in source.rglob("00README.json"):
        try:
            metadata = json.loads(manifest.read_text(encoding="utf-8"))
        except (UnicodeError, ValueError):
            continue
        sources = metadata.get("sources") if isinstance(metadata, dict) else None
        for entry in sources if isinstance(sources, list) else []:
            if isinstance(entry, dict) and entry.get("usage") == "toplevel" and isinstance(entry.get("filename"), str):
                candidate = manifest.parent.joinpath(*relative_path(entry["filename"]).parts)
                if candidate.suffix.lower() == ".tex" and candidate.is_file():
                    entries.add(candidate)
    if not entries:
        for path in source.rglob("*.tex"):
            try:
                text = without_comments(tex_text(path))
            except UnicodeError:
                continue
            if CLASS.search(text) and DOCUMENT.search(text):
                entries.add(path)
    if len(entries) != 1:
        choices = ", ".join(str(path.relative_to(source)) for path in sorted(entries))
        raise WorkflowError(f"需要唯一的主 .tex；候选：{choices or '无'}。可用 prepare --main 指定。")
    return entries.pop()


def add_chinese_setup(path):
    text = tex_text(path)
    clean = without_comments(text)
    begin = DOCUMENT.search(clean)
    if not begin:
        raise WorkflowError(f"主文件没有 \\begin{{document}}：{path.name}。")
    if re.search(r"\\(?:usepackage|RequirePackage|documentclass)\s*(?:\[[^\]]*\])?\s*"
                 r"\{[^{}]*\b(?:ctex(?:art|rep|book|beamer)?|xeCJK)\b[^{}]*\}", clean[:begin.start()]):
        return
    path.write_text(text[:begin.start()] + "\n" + CJK + "\n" + text[begin.start():], encoding="utf-8")


def prepare(job, selected):
    manifest = job / "project.json"
    source_en, source_zh = job / "source-en", job / "source-zh"
    if manifest.is_file() and source_en.is_dir() and source_zh.is_dir():
        project = json.loads(manifest.read_text(encoding="utf-8"))
        if selected and str(relative_path(selected)) != project["main"]:
            raise WorkflowError("目录已有翻译工程。要更换主文件，请换一个 --out 目录。")
        return project
    if manifest.exists() or source_en.exists() or source_zh.exists():
        raise WorkflowError("该目录已有不完整的工程，请换一个 --out 目录。")
    if not (job / "source").is_file() or not is_pdf(job / "original.pdf"):
        raise WorkflowError("缺少 arXiv 文件。请先运行 fetch。")
    with tempfile.TemporaryDirectory(prefix=".prepare-", dir=job) as temp:
        original = Path(temp) / "en"
        translated = Path(temp) / "zh"
        original.mkdir()
        unpack(job / "source", original)
        main = choose_main(original, selected).relative_to(original)
        shutil.copytree(original, translated)
        add_chinese_setup(translated / main)
        files = sorted(path.relative_to(original).as_posix() for path in original.rglob("*.tex") if path.is_file())
        project = {"job": str(job), "main": main.as_posix(), "translation_source": str(source_zh), "tex_files": files}
        receipt = Path(temp) / "project.json"
        receipt.write_text(json.dumps(project, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        original.rename(source_en)
        translated.rename(source_zh)
        receipt.rename(manifest)
    return project


def inventory(root):
    if not root.is_dir() or root.is_symlink():
        raise WorkflowError(f"缺少普通源码目录：{root}。")
    result = {}
    for path in root.rglob("*"):
        if path.is_symlink() or not (path.is_file() or path.is_dir()):
            raise WorkflowError(f"源码目录中不允许链接或特殊文件：{path}。")
        if path.is_file():
            result[path.relative_to(root)] = path
    return result


def audit(original, translated):
    before, after = inventory(original), inventory(translated)
    if before.keys() != after.keys():
        different = ", ".join(map(str, sorted(before.keys() ^ after.keys())))
        raise WorkflowError(f"源码文件集合发生变化：{different}。")
    issues, unchanged = [], []
    for relative, path in sorted(before.items()):
        if relative.suffix.lower() != ".tex":
            if not filecmp.cmp(path, after[relative], shallow=False):
                issues.append(f"{relative}：非 .tex 资源被修改")
            continue
        original_text = without_comments(tex_text(path))
        translated_text = without_comments(tex_text(after[relative]))
        if original_text == translated_text:
            unchanged.append(relative.as_posix())
        for kind, pattern in PROTECTED.items():
            normalize = (lambda value: " ".join(value.split())) if pattern is LAYOUT_ARGUMENTS else str.strip
            originals = Counter(normalize(match[0]) for match in pattern.finditer(original_text))
            translations = Counter(normalize(match[0]) for match in pattern.finditer(translated_text))
            if originals != translations:
                issues.append(f"{relative}：{kind}改动")
    if issues:
        raise WorkflowError("结构检查失败：\n" + "\n".join(issues))
    return unchanged


def included_tex(root, main):
    pending = [main]
    seen = set()
    entry_dir = root / main.parent
    while pending:
        relative = pending.pop()
        if relative in seen:
            continue
        text = without_comments(tex_text(root / relative))
        seen.add(relative)
        yield relative, text
        for match in INCLUDED_TEX.finditer(text):
            try:
                name = relative_path(match[1].strip())
            except WorkflowError:
                continue
            if not name.parts:
                continue
            if not name.suffix:
                name = name.with_suffix(".tex")
            if name.suffix.lower() != ".tex":
                continue
            for folder in (entry_dir, root / relative.parent):
                candidate = folder / name
                if candidate.is_file():
                    pending.append(candidate.relative_to(root))
                    break


def readable(text):
    for name in ("公式", "引用、模板和资源", "环境"):
        text = PROTECTED[name].sub(" ", text)
    return re.sub(r"\\[A-Za-z@]+\*?", " ", text)


def headings(text):
    for match in HEADING.finditer(text):
        depth = 1
        start = match.end()
        for brace in re.finditer(r"(?<!\\)[{}]", text[start:]):
            depth += 1 if brace[0] == "{" else -1
            if not depth:
                label = " ".join(readable(text[start:start + brace.start()]).split())
                if len(ENGLISH_WORD.findall(label)) >= 2 and not HAN.search(label):
                    yield match[1], label
                break


def narrative(text):
    begin = DOCUMENT.search(text)
    if begin:
        text = text[begin.end():]
    text = CODE_BLOCK.sub("\n\n", text)
    return readable(text)


def full_translation_coverage(original, translated, main):
    gaps = []
    checked_files = checked_blocks = 0
    for relative, english in included_tex(original, main):
        chinese = without_comments(tex_text(translated / relative))
        checked_files += 1
        unchanged_headings = Counter(headings(english)) & Counter(headings(chinese))
        for (_, label), _count in unchanged_headings.items():
            gaps.append(f"{relative}：未翻译的标题或图注「{label[:100]}」")
        published = f" {' '.join(ENGLISH_WORD.findall(narrative(chinese).lower()))} "
        for paragraph in re.split(r"\n[ \t\r]*\n", narrative(english)):
            words = ENGLISH_WORD.findall(paragraph.lower())
            if len(words) < 20 or (len(words) < 32 and not re.search(r"[.!?](?:\s|$)", paragraph)):
                continue
            checked_blocks += 1
            positions = sorted({0, (len(words) - 18) // 2, len(words) - 18})
            for start in positions:
                sample = " ".join(words[start:start + 18])
                if f" {sample} " in published:
                    gaps.append(f"{relative}：仍有英文原段落「{sample[:100]}…」")
                    break
    if gaps:
        details = "\n".join(gaps[:18])
        raise WorkflowError(f"全文检查发现 {len(gaps)} 处可能漏译，请逐处确认；选译须使用 --draft。\n{details}")
    return {"checked_tex": checked_files, "checked_passages": checked_blocks}


def require_program(name):
    binary = shutil.which(name)
    if not binary and name in {"xelatex", "bibtex", "fmtutil-user", "kpsewhich", "xdvipdfmx"}:
        candidate = Path("/Library/TeX/texbin") / name
        if candidate.is_file():
            binary = str(candidate)
    if not binary:
        raise WorkflowError(f"本机没有 {name}。请检查 TeX Live / Poppler 依赖。")
    return os.path.abspath(binary)


def run_tex(args, cwd, log, environment, allow_bib_warnings=False):
    started = perf_counter()
    with log.open("ab") as stream:
        stream.write(f"\n--- {' '.join(args)} ---\n".encode("utf-8"))
        stream.flush()
        try:
            result = subprocess.run(args, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=150)
        except subprocess.TimeoutExpired as error:
            raise WorkflowError("编译超过时限") from error
        stream.write(f"\n--- {Path(args[0]).name}: {perf_counter() - started:.2f}s ---\n".encode("utf-8"))
    if result.returncode == 1 and allow_bib_warnings:
        auxiliary_log = cwd / f"{Path(args[-1]).stem}.blg"
        if auxiliary_log.is_file() and re.search(r"(?mi)^\(There (?:was|were) \d+ warnings?\)",
                                               auxiliary_log.read_text(encoding="utf-8", errors="replace")):
            return
    if result.returncode:
        diagnostic = compile_diagnostic(log)
        summary = f"{Path(args[0]).name} 编译失败"
        raise WorkflowError(f"{summary}：{diagnostic}" if diagnostic else summary)


def compile_diagnostic(log):
    with log.open("rb") as stream:
        end = stream.seek(0, os.SEEK_END)
        stream.seek(max(0, end - 32 * 1024))
        lines = stream.read().decode("utf-8", errors="replace").splitlines()
    for row in reversed(lines):
        stripped = row.strip()
        if TEX_ERROR.search(stripped):
            return stripped[:170]
    return ""


def probe_pdf(path, tool):
    result = subprocess.run([tool, str(path)], stdin=subprocess.DEVNULL, capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=60)
    if result.returncode:
        raise WorkflowError(f"无法读取 PDF：{path.name}（{Path(tool).name}）。")
    return result.stdout


def build_environment(scratch):
    environment = {key: os.environ[key] for key in ("PATH", "HOME", "LANG", "LC_ALL", "TEXMFHOME")
                   if key in os.environ}
    environment.update(openin_any="p", openout_any="p", TEXMFOUTPUT=str(scratch), TMPDIR=str(scratch))
    return environment


def document_entry(job):
    receipt = job / "project.json"
    if not receipt.is_file():
        raise WorkflowError("请先运行 prepare。")
    return relative_path(json.loads(tex_text(receipt))["main"])


def dependency_check(source, main):
    kpsewhich = require_program("kpsewhich")
    dependencies, templates = set(), set()
    for relative, text in included_tex(source, main):
        for match in PACKAGE.finditer(text):
            for package in match[1].split(","):
                name = package.strip()
                if not re.fullmatch(r"[\w-]+", name):
                    continue
                if relative == main:
                    dependencies.add(f"{name}.sty")
                for folder in (source / main.parent, source / relative.parent):
                    candidate = folder / f"{name}.sty"
                    if candidate.is_file():
                        templates.add(candidate)
    expect_fonts = {f"{match[1]}.tfm" for template in templates
                    for match in FONT_METRIC.finditer(without_comments(tex_text(template)))}
    dependencies.update(expect_fonts)
    dependencies.difference_update(path.name for path in templates)
    report = {"checked": len(dependencies), "missing": []}
    if dependencies:
        names = sorted(dependencies)
        probe = subprocess.run([kpsewhich, "-progname=xelatex", *names], cwd=source / main.parent,
                               env=build_environment(source), capture_output=True, encoding="utf-8",
                               errors="replace", timeout=20, stdin=subprocess.DEVNULL)
        resolved = {Path(line).name for line in probe.stdout.splitlines() if line}
        report["missing"] = sorted(dependencies - resolved)
    return report


def preflight(job):
    main = document_entry(job)
    for name in ("xelatex", "xdvipdfmx", "pdfinfo", "pdftotext"):
        require_program(name)
    return dependency_check(job / "source-zh", main)


def auxiliary_has_bibliography(aux, cwd):
    pending = [aux]
    seen = set()
    while pending:
        path = pending.pop()
        if path in seen or not path.is_file():
            continue
        seen.add(path)
        value = path.read_bytes()
        if BIB_DATA in value:
            return True
        for name in BIB_LIST.findall(value):
            try:
                relative = relative_path(name.decode("utf-8"))
            except (UnicodeError, WorkflowError):
                continue
            pending.append(cwd / relative)
    return False


def first_pass(command, cwd, log, environment, scratch):
    try:
        run_tex(command, cwd, log, environment)
    except WorkflowError:
        diagnostics = log.read_text(encoding="utf-8", errors="replace")
        if "You have requested release" not in diagnostics:
            raise
        environment = {**environment, "TEXMFVAR": str(scratch / "tex-var"),
                       "TEXMFCONFIG": str(scratch / "tex-config")}
        run_tex([require_program("fmtutil-user"), "--byfmt", "xelatex"], scratch, log,
                {**environment, "shell_escape": "f"})
        run_tex(command, cwd, log, environment)
    return environment


def build(job, draft):
    started = perf_counter()
    main = document_entry(job)
    original = job / "source-en"
    translated = job / "source-zh"
    unchanged = audit(original, translated)
    coverage = None if draft else full_translation_coverage(original, translated, main)
    engine, converter, pdfinfo, pdftotext = map(require_program, ("xelatex", "xdvipdfmx", "pdfinfo", "pdftotext"))
    destination = job / ("translated.zh-draft.pdf" if draft else "translated.zh.pdf")
    log = job / ("build-draft.log" if draft else "build.log")
    with tempfile.TemporaryDirectory(prefix=".compile-", dir=job) as temp:
        source = Path(temp) / "src"
        shutil.copytree(translated, source)
        entry = source.joinpath(*main.parts)
        if not entry.is_file() or entry.suffix.lower() != ".tex":
            raise WorkflowError("未找到准备阶段选定的主 .tex 文件。")
        cwd = entry.parent
        built = entry.with_suffix(".pdf")
        if built.exists():
            raise WorkflowError("主 .tex 与归档内 PDF 同名，不能确认编译产物。")
        environment = {**build_environment(Path(temp)), "TEXMFOUTPUT": str(cwd)}
        staging_log = Path(temp) / "run.log"
        command = [engine, "-no-shell-escape", "-no-pdf", "-interaction=nonstopmode", "-halt-on-error",
                   "-file-line-error", f"./{entry.name}"]
        tex_log = entry.with_suffix(".log")
        passes = 1
        try:
            environment = first_pass(command, cwd, staging_log, environment, Path(temp))
            aux = entry.with_suffix(".aux")
            bibliography = not entry.with_suffix(".bbl").is_file() and auxiliary_has_bibliography(aux, cwd)
            if bibliography:
                run_tex([require_program("bibtex"), f"./{entry.stem}"], cwd, staging_log, environment,
                        allow_bib_warnings=True)
            final_log = tex_log.read_text(encoding="utf-8", errors="replace")
            while passes < 3 and (RERUN.search(final_log) or (bibliography and passes < 3)):
                run_tex(command, cwd, staging_log, environment)
                passes += 1
                final_log = tex_log.read_text(encoding="utf-8", errors="replace")
            if "Missing character:" in final_log:
                raise WorkflowError("PDF 存在缺字")
            run_tex([converter, "-q", "-o", f"./{entry.stem}.pdf", f"./{entry.stem}.xdv"],
                    cwd, staging_log, environment)
        except WorkflowError as error:
            raise WorkflowError(f"{error}；请检查 {log}。") from error
        finally:
            if staging_log.is_file():
                staging_log.replace(log)
        if not is_pdf(built):
            raise WorkflowError(f"XeLaTeX 没有生成有效 PDF；请检查 {log}。")
        info = probe_pdf(built, pdfinfo)
        pages = re.search(r"(?m)^Pages:\s+(\d+)", info)
        if not pages or int(pages[1]) < 1:
            raise WorkflowError("无法确认 PDF 页数。")
        extract = subprocess.run([pdftotext, "-enc", "UTF-8", str(built), "-"], stdin=subprocess.DEVNULL,
                                 capture_output=True, check=True, text=True, encoding="utf-8", timeout=60)
        if not HAN.search(extract.stdout):
            raise WorkflowError("PDF 未检出可抽取的中文，请确认译文和中文字体。")
        built.replace(destination)
    return {"pdf": str(destination), "original": str(job / "original.pdf"), "pages": int(pages[1]),
            "draft": draft, "log": str(log), "unchanged_tex": unchanged, "coverage": coverage,
            "passes": passes, "seconds": round(perf_counter() - started, 2),
            "overfull_boxes": len(re.findall(r"Overfull \\[hv]box", final_log)),
            "unresolved_refs": bool(UNRESOLVED.search(final_log))}


def main():
    parser = argparse.ArgumentParser(description="下载 arXiv LaTeX 工程并构建保留模板的中文译文 PDF。")
    actions = parser.add_subparsers(dest="action", required=True)
    fetch_parser = actions.add_parser("fetch", help="下载原文与同版本源码")
    fetch_parser.add_argument("paper")
    fetch_parser.add_argument("--out", type=Path, default=Path("output/pdf/arxiv"))
    prepare_parser = actions.add_parser("prepare", help="离线准备独立的中英文源码目录")
    prepare_parser.add_argument("job", type=Path)
    prepare_parser.add_argument("--main", help="归档中的主 .tex 相对路径")
    preflight_parser = actions.add_parser("preflight", help="离线检查已知的入口宏包和字体依赖")
    preflight_parser.add_argument("job", type=Path)
    build_parser = actions.add_parser("build", help="检查结构、编译并验证中文 PDF")
    build_parser.add_argument("job", type=Path)
    build_parser.add_argument("--draft", action="store_true", help="明确标记为选译或未核对稿")
    args = parser.parse_args()
    try:
        if args.action == "fetch":
            result = fetch(args.paper, args.out)
        elif args.action == "prepare":
            result = prepare(args.job.resolve(), args.main)
        elif args.action == "preflight":
            result = preflight(args.job.resolve())
        else:
            result = build(args.job.resolve(), args.draft)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except (WorkflowError, OSError, ValueError, KeyError, tarfile.TarError, URLError, subprocess.SubprocessError) as error:
        parser.exit(1, f"错误：{error}\n")


if __name__ == "__main__":
    main()
