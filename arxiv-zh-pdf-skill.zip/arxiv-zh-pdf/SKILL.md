---
name: arxiv-zh-pdf
description: ＋云翻译：把 arXiv 论文链接、编号或幻觉翻译论文页变成保留原模板、公式和图表的简体中文 PDF，并在本地网页中英对照。用于“arXiv 中文 PDF”“原版式翻译整篇论文”或“打开＋云翻译”；不用于只要摘要的请求。
---

# ＋云翻译

用当前 Codex 翻译 arXiv 的 LaTeX 源码，再在本机重编译。保留原 PDF 和版本号，不依赖幻觉翻译、额外的翻译 API Key 或浏览器登录。中文换行、浮动体和分页可能与原版不同。

默认从当前工作区运行一次：

```bash
python3 "$HOME/.agents/skills/arxiv-zh-pdf/scripts/reader.py" --translate '<arXiv 链接或编号>'
```

脚本负责固定版本、依赖预检、分批翻译与续跑、断网编译和输出校验。链接中的 `#S3` 等锚点不缩小范围。成功时只交付输出的 **中文 PDF**，不另做合并或并排 PDF；需要网页才按 [本地阅读器](references/local-reader.md) 启动，原文仅保留为本地对照。

以脚本的自检结果为准，不逐项播报，不为验收打开 PDF、渲染页面或查看截图。只有用户明确要求版面检查时才另做目视检查。遇到阻塞或警告先看 [编译与检查](references/source-workflow.md) 和日志，只处理出问题的步骤，不重做已有译文。不把选译、原文或未编译的源码称为整篇中文 PDF。
