export function makeAlignment(fromOutline, toOutline, fromEnd, toEnd) {
  const other = new Map(toOutline.filter(({ key }) => key).map(({ key, position }) => [key, position]));
  const pairs = fromOutline.flatMap(({ key, position }) => other.has(key) ? [[position, other.get(key)]] : [])
    .sort((left, right) => left[0] - right[0] || left[1] - right[1]);
  const anchors = [[1, 1]];
  for (const [from, to] of pairs) {
    const [lastFrom, lastTo] = anchors.at(-1);
    if (from > lastFrom && from < fromEnd && to > lastTo && to < toEnd) anchors.push([from, to]);
  }
  anchors.push([fromEnd, toEnd]);
  return { anchors, count: anchors.length - 2 };
}

export function mappedPosition(position, alignment) {
  const { anchors } = alignment;
  const bounded = Math.max(1, Math.min(position, anchors.at(-1)[0]));
  const upperIndex = anchors.findIndex(([source], index) => index > 0 && source >= bounded);
  const [lowerFrom, lowerTo] = anchors[upperIndex - 1];
  const [upperFrom, upperTo] = anchors[upperIndex];
  const progress = upperFrom > lowerFrom ? (bounded - lowerFrom) / (upperFrom - lowerFrom) : 0;
  return lowerTo + progress * (upperTo - lowerTo);
}
