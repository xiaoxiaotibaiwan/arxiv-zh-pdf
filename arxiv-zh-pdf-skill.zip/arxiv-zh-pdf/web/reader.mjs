import { getDocument, GlobalWorkerOptions, TextLayer } from '/pdfjs/pdf.min.mjs';
import { makeAlignment, mappedPosition } from '/alignment.mjs';

GlobalWorkerOptions.workerSrc = '/pdfjs/pdf.worker.min.mjs';

const byId = (id) => document.getElementById(id);
const panes = byId('panes');
const states = { fetching: '正在从 arXiv 取稿', translating: '正在翻译全文', checking: '正在排版和检查中文 PDF' };
const app = { views: {}, paper: null, mode: 'split', active: 'zh', zoom: 1, sync: true, api: null,
  outline: false, bannerKey: '', dismissed: '', manual: '', pending: false, followTask: false };

function preferences(key, value) {
  try {
    if (value !== undefined) localStorage.setItem(key, value);
    else return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function applyTheme(value) {
  const dark = value === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  byId('theme').querySelector('use').setAttribute('href', dark ? '#sun' : '#moon');
  byId('theme').setAttribute('aria-label', dark ? '切换浅色界面' : '切换深色界面');
}

async function pdfOutline(pdf) {
  const result = [];
  async function entryFor(item, depth) {
    const key = typeof item.dest === 'string' ? item.dest : null;
    const dest = key ? await pdf.getDestination(key) : item.dest;
    if (!dest?.length) return null;
    const page = 1 + (Number.isInteger(dest[0]) ? dest[0] : await pdf.getPageIndex(dest[0]));
    if (page < 1 || page > pdf.numPages) return null;
    const kind = dest[1]?.name;
    const top = kind === 'XYZ' ? dest[3] : ['FitH', 'FitBH'].includes(kind) ? dest[2] : null;
    let position = page;
    if (Number.isFinite(top)) {
      const pdfPage = await pdf.getPage(page);
      const viewport = pdfPage.getViewport({ scale: 1 });
      if (viewport.rotation % 180 === 0) {
        const [, vertical] = viewport.convertToViewportPoint(0, top);
        position += Math.max(0, Math.min(.999, vertical / viewport.height));
      }
    }
    return { title: item.title, key, position, depth };
  }
  async function walk(items, depth) {
    for (const item of items) {
      if (item.dest) {
        const entry = await entryFor(item, depth).catch(() => null);
        if (entry) result.push(entry);
      }
      if (item.items?.length) await walk(item.items, depth + 1);
    }
  }
  await walk((await pdf.getOutline()) || [], 0);
  return result;
}

class Pane {
  constructor(language, url, id, scope, position = 1) {
    this.language = language;
    this.url = url;
    this.position = position;
    this.lastTop = 0;
    this.deleted = false;
    this.outline = [];
    this.slots = [];
    this.rendered = new Map();
    this.width = 0;
    this.scrollFrame = 0;
    this.paintFrame = 0;
    this.element = byId('pane-template').content.firstElementChild.cloneNode(true);
    this.element.dataset.lang = language;
    const get = (selector) => this.element.querySelector(selector);
    const label = language === 'en' ? '英文原文' : scope ? '中文选译' : '中文译文';
    get('strong').textContent = label;
    if (scope) get('.pane-name').title = scope;
    this.well = get('.paper-well');
    this.well.setAttribute('aria-label', label);
    this.stack = get('.page-stack');
    this.message = get('.pane-message');
    this.count = get('.page-count');
    const download = get('.download');
    if (url) {
      download.href = url;
      download.download = `${id}.${language === 'zh' ? (scope ? 'zh-draft' : 'zh') : 'en'}.pdf`;
      download.setAttribute('aria-label', `下载${label} PDF`);
    } else {
      download.hidden = true;
    }
    this.element.addEventListener('pointerdown', () => { app.active = language; });
    this.element.addEventListener('focusin', () => { app.active = language; });
    this.well.addEventListener('scroll', () => this.scheduleScroll(), { passive: true });
    this.resize = new ResizeObserver(() => this.layout());
    this.resize.observe(this.well);
  }

  updatePageNumber() {
    if (!this.slots.length) return;
    const max = this.maxTop();
    const top = this.well.scrollTop;
    const page = max > 0 && top >= max - 1 ? this.slots.length : Math.floor(this.positionAt(top));
    const value = `${page} / ${this.slots.length}`;
    if (this.count.textContent !== value) this.count.textContent = value;
  }

  async load() {
    if (!this.url) {
      this.message.textContent = '译文还未生成。可先阅读英文原文。';
      return;
    }
    try {
      this.loading = getDocument({ url: this.url, cMapUrl: '/pdfjs/cmaps/', cMapPacked: true,
        standardFontDataUrl: '/pdfjs/standard_fonts/', useWasm: false, isEvalSupported: false });
      const pdf = await this.loading.promise;
      if (this.deleted) return;
      const first = await pdf.getPage(1);
      if (this.deleted) return;
      const viewport = first.getViewport({ scale: 1 });
      this.aspect = viewport.width / viewport.height;
      this.stack.style.setProperty('--aspect', this.aspect);
      this.slots = Array.from({ length: pdf.numPages }, () => {
        const sheet = document.createElement('div');
        sheet.className = 'page-sheet';
        return sheet;
      });
      const fragment = document.createDocumentFragment();
      this.slots.forEach((slot) => fragment.append(slot));
      this.stack.append(fragment);
      this.pdf = pdf;
      this.stack.hidden = false;
      this.message.hidden = true;
      this.layout();
      updateReader();
      this.outline = await pdfOutline(pdf).catch(() => []);
      if (this.deleted) return;
      updateReader();
    } catch {
      if (!this.deleted) {
        this.message.hidden = false;
        this.message.textContent = '无法打开 PDF，请下载查看。';
      }
    }
  }

  layout() {
    const client = this.well.clientWidth;
    if (this.deleted || !this.slots.length || client < 40) return;
    const gutter = Number.parseFloat(getComputedStyle(this.well).getPropertyValue('--paper-gutter'));
    const width = Math.floor(Math.min(client - 2 * gutter, 1120) * app.zoom);
    if (width !== this.width) {
      this.width = width;
      this.stack.style.setProperty('--sheet-width', `${width}px`);
      for (const index of this.rendered.keys()) this.discard(index);
    }
    this.seek(this.position);
  }

  maxTop() { return Math.max(0, this.well.scrollHeight - this.well.clientHeight); }

  indexAt(offset) {
    let first = 0;
    let end = this.slots.length;
    while (first + 1 < end) {
      const middle = (first + end) >> 1;
      if (this.slots[middle].offsetTop <= offset) first = middle;
      else end = middle;
    }
    return first;
  }

  stride(index) {
    const slot = this.slots[index];
    const next = this.slots[index + 1];
    return next ? next.offsetTop - slot.offsetTop : slot.offsetHeight;
  }

  positionAt(top) {
    const offset = top + this.slots[0].offsetTop;
    const index = this.indexAt(offset);
    const inset = offset - this.slots[index].offsetTop;
    return index + 1 + Math.max(0, Math.min(.99999, inset / Math.max(1, this.stride(index))));
  }

  seek(position) {
    if (!this.slots.length || !this.well.clientWidth) {
      this.position = position;
      return;
    }
    const bounded = Math.max(1, Math.min(this.slots.length + .99999, position));
    const index = Math.floor(bounded) - 1;
    const top = this.slots[index].offsetTop - this.slots[0].offsetTop + (bounded - index - 1) * this.stride(index);
    this.well.scrollTop = top;
    this.lastTop = this.well.scrollTop;
    this.position = this.positionAt(this.lastTop);
    this.updatePageNumber();
    this.queuePaint();
  }

  scheduleScroll() {
    if (this.scrollFrame || !this.slots.length) return;
    this.scrollFrame = requestAnimationFrame(() => {
      this.scrollFrame = 0;
      if (this.deleted || !this.well.clientWidth) return;
      const top = this.well.scrollTop;
      if (top === this.lastTop) return;
      this.lastTop = top;
      this.position = this.positionAt(top);
      this.updatePageNumber();
      this.queuePaint();
      app.active = this.language;
      syncFrom(this);
    });
  }

  queuePaint() {
    if (this.paintFrame) return;
    this.paintFrame = requestAnimationFrame(() => {
      this.paintFrame = 0;
      const height = this.well.clientHeight;
      if (!this.width || !height || !this.well.clientWidth || this.deleted) return;
      const top = this.well.scrollTop;
      const start = this.indexAt(top - height * .55);
      const end = this.indexAt(top + height * 1.55);
      const visible = this.indexAt(top);
      for (const index of this.rendered.keys()) {
        if (index < start || index > end) this.discard(index);
      }
      for (let step = 0; step <= Math.max(end - visible, visible - start); step += 1) {
        if (visible + step <= end) this.paint(visible + step);
        if (step && visible - step >= start) this.paint(visible - step);
      }
    });
  }

  discard(index) {
    const record = this.rendered.get(index);
    if (!record) return;
    this.rendered.delete(index);
    record.rendering?.cancel();
    record.textLayer?.cancel();
    this.slots[index].replaceChildren();
  }

  async paint(index) {
    if (this.rendered.has(index)) return;
    const record = {};
    this.rendered.set(index, record);
    const current = () => !this.deleted && this.rendered.get(index) === record;
    const slot = this.slots[index];
    try {
      const page = await this.pdf.getPage(index + 1);
      if (!current()) return;
      const natural = page.getViewport({ scale: 1 });
      const aspect = natural.width / natural.height;
      if (Math.abs(aspect - this.aspect) > .0001 && !slot.style.getPropertyValue('--aspect')) {
        slot.style.setProperty('--aspect', aspect);
        this.seek(this.position);
      }
      const viewport = page.getViewport({ scale: this.width / natural.width });
      const ratio = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(5200000 / (viewport.width * viewport.height)));
      const canvas = document.createElement('canvas');
      canvas.setAttribute('aria-hidden', 'true');
      canvas.width = Math.ceil(viewport.width * ratio);
      canvas.height = Math.ceil(viewport.height * ratio);
      canvas.style.width = `${viewport.width}px`;
      canvas.style.height = `${viewport.height}px`;
      record.rendering = page.render({ canvas, viewport, transform: [ratio, 0, 0, ratio, 0, 0] });
      await record.rendering.promise;
      if (!current()) return;
      const text = document.createElement('div');
      text.className = 'textLayer';
      text.style.setProperty('--total-scale-factor', viewport.scale);
      slot.replaceChildren(canvas, text);
      record.textLayer = new TextLayer({ textContentSource: page.streamTextContent(), container: text, viewport });
      await record.textLayer.render().catch(() => {});
    } catch (error) {
      if (!current() || error?.name === 'RenderingCancelledException') return;
      const message = document.createElement('div');
      message.className = 'page-error';
      message.textContent = `第 ${index + 1} 页无法显示，请下载 PDF。`;
      slot.replaceChildren(message);
    }
  }

  close() {
    this.deleted = true;
    cancelAnimationFrame(this.scrollFrame);
    cancelAnimationFrame(this.paintFrame);
    for (const index of this.rendered.keys()) this.discard(index);
    this.resize.disconnect();
    this.loading?.destroy().catch(() => {});
  }
}

function otherLanguage(language) { return language === 'zh' ? 'en' : 'zh'; }

function syncFrom(source) {
  if (!app.sync || app.mode !== 'split' || !source?.pdf || !source.well.clientWidth) return;
  const target = app.views[otherLanguage(source.language)];
  if (!target?.pdf || !target.well.clientWidth) return;
  const alignment = makeAlignment(source.outline, target.outline,
    source.positionAt(source.maxTop()), target.positionAt(target.maxTop()));
  target.seek(mappedPosition(source.position, alignment));
}

function setMode(mode) {
  app.mode = mode;
  if (mode !== 'split') app.active = mode;
  panes.dataset.mode = mode;
  document.querySelectorAll('[data-mode][aria-pressed]').forEach((button) => {
    button.setAttribute('aria-pressed', button.dataset.mode === mode);
  });
  Object.values(app.views).forEach((view) => view.layout());
  syncFrom(app.views[app.active]);
  updateReader();
}

function updateReader() {
  const linked = Boolean(app.mode === 'split' && app.views.zh?.pdf && app.views.en?.pdf);
  byId('sync').disabled = !linked;
  byId('sync').setAttribute('aria-pressed', linked && app.sync);
  if (!app.outline) return;
  const outlineList = byId('outline-list');
  const view = app.mode === 'split' ? (app.views.zh?.outline.length ? app.views.zh : app.views.en) : app.views[app.mode];
  if (!view?.outline.length) {
    const empty = document.createElement('span');
    empty.className = 'outline-empty';
    empty.textContent = '当前 PDF 暂无书签。';
    outlineList.replaceChildren(empty);
    return;
  }
  outlineList.replaceChildren(...view.outline.map((entry) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.style.setProperty('--depth', Math.min(entry.depth, 3));
    button.textContent = entry.title;
    button.addEventListener('click', () => {
      app.active = view.language;
      view.seek(entry.position);
      syncFrom(view);
      toggleOutline(false);
      view.well.focus({ preventScroll: true });
    });
    return button;
  }));
}

function toggleOutline(show) {
  app.outline = show;
  byId('outline').hidden = !show;
  byId('outline-toggle').setAttribute('aria-expanded', show);
  updateReader();
}

function paperTitle(paper) { return paper.title || paper.titleEn || `arXiv ${paper.paper}`; }

function paperPath(id) { return `/?${new URLSearchParams({ paper: id })}`; }

function openPaper(paper, navigate = false) {
  const current = app.paper;
  if (current?.id === paper.id && current.translated === paper.translated) return;
  const positions = current?.id === paper.id ? Object.fromEntries(Object.entries(app.views).map(([key, view]) => [key, view.position])) : {};
  Object.values(app.views).forEach((view) => view.close());
  app.paper = paper;
  byId('home').hidden = true;
  byId('reader').hidden = false;
  document.title = `${paperTitle(paper)} · ＋云翻译`;
  app.active = paper.translated ? 'zh' : 'en';
  app.views = { zh: new Pane('zh', paper.translated, paper.id, paper.draft ? paper.scope || '部分内容已翻译' : '', positions.zh),
    en: new Pane('en', paper.original, paper.id, '', positions.en) };
  panes.replaceChildren(app.views.zh.element, app.views.en.element);
  toggleOutline(false);
  setMode(paper.translated ? 'split' : 'en');
  if (navigate) {
    app.followTask = false;
    if (window.location.search !== new URL(paperPath(paper.id), window.location.href).search) {
      window.history.pushState(null, '', paperPath(paper.id));
    }
    app.views[app.active].well.focus({ preventScroll: true });
  }
  Object.values(app.views).forEach((view) => view.load());
}

function showHome(navigate = false) {
  Object.values(app.views).forEach((view) => view.close());
  app.views = {};
  app.paper = null;
  panes.replaceChildren();
  byId('reader').hidden = true;
  byId('home').hidden = false;
  document.title = '＋云翻译';
  if (navigate) {
    app.followTask = false;
    window.history.pushState(null, '', '/');
    byId('paper-input').focus();
  }
}

function normalClick(event) {
  return event.button === 0 && !event.altKey && !event.metaKey && !event.ctrlKey && !event.shiftKey;
}

function updateShelf(library) {
  const shelf = byId('shelf');
  shelf.hidden = !library.papers.length;
  const stamp = JSON.stringify(library.papers.map((paper) => [paper.id, paperTitle(paper), paper.draft, paper.translated]));
  if (shelf.dataset.stamp === stamp) return;
  shelf.dataset.stamp = stamp;
  shelf.replaceChildren(...library.papers.map((paper) => {
    const link = document.createElement('a');
    link.href = paperPath(paper.id);
    link.textContent = paperTitle(paper);
    link.title = `${paper.paper}${paper.draft ? ' · 中文选译' : !paper.translated ? ' · 英文原文' : ''}`;
    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.classList.add('icon');
    icon.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#right');
    icon.append(use);
    link.append(icon);
    link.addEventListener('click', (event) => {
      if (!normalClick(event)) return;
      event.preventDefault();
      openPaper(paper, true);
    });
    return link;
  }));
}

function openLocation() {
  const desired = new URLSearchParams(window.location.search).get('paper');
  if (!desired) {
    if (app.paper) showHome();
    return;
  }
  const paper = app.api?.papers.find(({ id }) => id === desired);
  if (paper) openPaper(paper);
  else if (app.api) {
    if (app.paper) showHome();
    announce('本地没有这篇论文。', 'warning', `missing:${desired}`);
  }
}

function announce(message, tone, key, manual = '') {
  if (key === app.dismissed || (key === app.bannerKey && !byId('job-banner').hidden)) return;
  app.bannerKey = key;
  app.manual = manual;
  byId('job-copy').textContent = message;
  byId('job-banner').dataset.tone = tone;
  byId('job-banner').hidden = false;
  byId('copy-command').hidden = !manual;
  byId('copy-command').textContent = '复制 Codex 指令';
}

async function refresh() {
  const response = await fetch('/api/library', { cache: 'no-store' });
  if (!response.ok) throw new Error('暂时无法连接本地书架。');
  const library = await response.json();
  app.api = library;
  byId('translate').title = library.engine ? '用已登录的 Codex 翻译' : '在 Codex 聊天中翻译';
  updateShelf(library);
  openLocation();
  const task = library.task;
  byId('translate').disabled = app.pending || Boolean(states[task?.state]);
  if (task && states[task.state]) {
    const progress = task.state === 'translating' && task.batches ? ` · ${task.completed}/${task.batches} 批` : '';
    if (task.id === app.paper?.id && !app.paper.translated) {
      app.views.zh.message.textContent = `${states[task.state]}${progress}`;
    }
    announce(`${states[task.state]}${progress} · ${task.paper}`, 'working', `${task.id}:${task.state}:${task.paper}${progress}`);
  }
  if (task?.state === 'ready') {
    const key = `${task.id}:ready`;
    if (app.followTask) {
      const completed = library.papers.find(({ id }) => id === task.id);
      if (completed) openPaper(completed, true);
      app.followTask = false;
    }
    if (app.bannerKey !== key && app.dismissed !== key) {
      announce(`中文译文已就绪 · ${task.paper}`, 'success', key);
    }
  }
  if (task?.state === 'error') {
    app.followTask = false;
    if (task.id === app.paper?.id && !app.paper.translated) app.views.zh.message.textContent = '翻译未完成';
    announce(`${task.paper}：${task.message}`, 'warning', `${task.id}:error:${task.message}`, `$arxiv-zh-pdf ${task.paper} 翻译整篇并生成中英对照 PDF`);
  }
}

async function submit(event) {
  event.preventDefault();
  const input = byId('paper-input');
  const text = input.value.trim();
  if (!text || app.pending || !app.api) return;
  app.pending = true;
  byId('translate').disabled = true;
  app.dismissed = '';
  try {
    const response = await fetch('/api/translate', { method: 'POST', headers: {
      'Content-Type': 'application/json', 'X-Reader-Token': app.api.token }, body: JSON.stringify({ paper: text }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || '无法提交。');
    if (result.open) {
      const paper = app.api.papers.find(({ id }) => id === result.open);
      if (paper) openPaper(paper, true);
      else {
        window.history.pushState(null, '', paperPath(result.open));
      }
      input.value = '';
    } else if (result.manual) {
      announce('请复制这条指令到 Codex 对话；生成的 PDF 会自动出现在书架。', 'success', `manual:${result.manual}`, `$arxiv-zh-pdf ${result.manual} 翻译整篇并生成中英对照 PDF`);
    } else if (result.started) {
      app.followTask = true;
      input.value = '';
      announce('正在取稿…', 'working', 'starting');
    } else if (result.busy) {
      announce('已有论文正在翻译。', 'working', 'busy');
    }
    await refresh();
  } catch (error) {
    announce(error.message, 'warning', `submit:${error.message}`);
  } finally {
    app.pending = false;
    byId('translate').disabled = Boolean(states[app.api?.task?.state]);
  }
}

function zoom(next) {
  app.zoom = Math.round(Math.max(.65, Math.min(2.25, next)) * 100) / 100;
  byId('reader').classList.toggle('is-zoomed', app.zoom > 1);
  byId('zoom-reset').textContent = app.zoom === 1 ? '适宽' : `${Math.round(app.zoom * 100)}%`;
  byId('zoom-out').disabled = app.zoom <= .65;
  byId('zoom-in').disabled = app.zoom >= 2.25;
  Object.values(app.views).forEach((view) => view.layout());
}

applyTheme(preferences('arxiv-zh-theme'));
byId('theme').addEventListener('click', () => {
  const value = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  applyTheme(value);
  preferences('arxiv-zh-theme', value);
});
byId('new-paper').addEventListener('click', (event) => {
  if (!normalClick(event)) return;
  event.preventDefault();
  showHome(true);
});
window.addEventListener('popstate', openLocation);
byId('dismiss-banner').addEventListener('click', () => {
  byId('job-banner').hidden = true;
  app.dismissed = app.bannerKey;
});
byId('copy-command').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(app.manual);
    byId('copy-command').textContent = '已复制';
  } catch {
    byId('job-copy').textContent = app.manual;
  }
});
byId('submit-paper').addEventListener('submit', submit);
byId('outline-toggle').addEventListener('click', () => toggleOutline(!app.outline));
byId('sync').addEventListener('click', () => {
  app.sync = !app.sync;
  updateReader();
  syncFrom(app.views[app.active]);
});
byId('zoom-out').addEventListener('click', () => zoom(app.zoom - .15));
byId('zoom-reset').addEventListener('click', () => zoom(1));
byId('zoom-in').addEventListener('click', () => zoom(app.zoom + .15));
document.querySelectorAll('[data-mode][aria-pressed]').forEach((button) => button.addEventListener('click', () => setMode(button.dataset.mode)));
document.addEventListener('pointerdown', (event) => {
  if (app.outline && !event.target.closest('#outline, #outline-toggle')) toggleOutline(false);
});
document.addEventListener('keydown', (event) => {
  if (app.outline && event.key === 'Escape') {
    toggleOutline(false);
    byId('outline-toggle').focus();
  }
});
refresh().catch((error) => announce(error.message, 'warning', 'connection'));
setInterval(() => refresh().catch(() => {}), 2500);
