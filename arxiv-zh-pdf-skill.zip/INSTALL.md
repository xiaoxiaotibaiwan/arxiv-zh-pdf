# ＋云翻译 · Codex Skill 安装说明

解压后有 `arxiv-zh-pdf/` 和这份说明。把整个 `arxiv-zh-pdf/` 文件夹放到 `~/.agents/skills/`，使入口为 `~/.agents/skills/arxiv-zh-pdf/SKILL.md`。已有同名 Skill 时，请先备份，不要直接覆盖。

从解压后的目录也可以在终端安装：

```bash
mkdir -p "$HOME/.agents/skills"
destination="$HOME/.agents/skills/arxiv-zh-pdf"
test ! -e "$destination" && test ! -L "$destination" && cp -R arxiv-zh-pdf "$destination"
```

打开本机 Codex 聊天，输入：

```text
$arxiv-zh-pdf https://arxiv.org/abs/2410.01508v2
```

如没发现 Skill，重启 Codex 后再试。默认交付中文 PDF，文件在当前工作区的 `output/pdf/arxiv/<论文版本>/`。支持有 LaTeX 源码的 arXiv 论文；默认不做截图验收。

## 运行依赖

- Python 3.10+，以及本机可执行的 Codex CLI。用接收方自己的账号登录（`codex login`）；下载和翻译需联网，不需要额外的翻译 API Key。
- TeX Live 或 MacTeX：需要 `xelatex`、`xdvipdfmx`、`kpsewhich`、`xeCJK`、Fandol 中文字体；部分论文还需要 BibTeX 和模板宏包。
- Poppler：需要 `pdfinfo` 和 `pdftotext`，不需要 `pdftoppm`。

此包在 macOS 本机验证；未验证 Windows 原生运行。不包含论文、译文、账号、缓存或上述依赖。

## 可选：中英对照阅读

在论文所在工作区执行：

```bash
python3 "$HOME/.agents/skills/arxiv-zh-pdf/scripts/reader.py" --enable-codex
```

打开终端显示的地址（默认 [http://127.0.0.1:8765/](http://127.0.0.1:8765/)）。网页仅在本机运行。若没有可用的 PDF.js，按 [阅读器说明](arxiv-zh-pdf/references/local-reader.md) 配置；只生成中文 PDF 不需要 PDF.js。

[Codex 本地 Skill 官方说明](https://developers.openai.com/codex/skills)
